# 🚀 爱情计时器网站 CDN 加速配置指南

## 📋 CDN优化概述

本指南将帮助您为爱情计时器网站配置CDN加速，提升全球访问速度和用户体验。

## 🎯 优化目标

- ✅ 静态资源加速（HTML/CSS/JS/图片）
- ✅ 字体文件加速
- ✅ API接口加速
- ✅ 图片压缩和WebP格式转换
- ✅ 缓存策略优化
- ✅ 全球节点分发

## 🔧 CDN服务商选择

### 推荐CDN服务商

1. **腾讯云CDN** - 适合国内用户，与您的服务器同平台
2. **阿里云CDN** - 国内覆盖面广
3. **Cloudflare** - 全球免费CDN，适合海外用户
4. **又拍云** - 国内专业CDN服务商
5. **七牛云** - 提供CDN和对象存储

## 📁 资源分类优化

### 1. 静态资源CDN
```
主页面：index.html
背景图片：/uploads/*
字体文件：Google Fonts CDN
```

### 2. API接口CDN
```
背景图列表：GET /api/backgrounds
上传图片：POST /api/upload
删除图片：DELETE /api/backgrounds/:id
```

## 🌐 CDN配置步骤

### 步骤1：腾讯云CDN配置（推荐）

#### 1.1 登录腾讯云控制台
1. 访问 [腾讯云CDN控制台](https://console.cloud.tencent.com/cdn)
2. 选择"内容分发网络CDN"

#### 1.2 添加CDN域名
```
加速域名：love-timer.yourdomain.com
源站地址：119.91.20.202:8080
加速类型：静态加速
```

#### 1.3 配置缓存规则
```javascript
// HTML文件
文件类型：html
缓存时间：1天

// 图片文件
文件类型：jpg, jpeg, png, gif, webp
缓存时间：30天

// API接口
路径：/api/*
缓存时间：不缓存（no-cache）

// 字体文件
文件类型：woff, woff2, ttf, otf
缓存时间：30天
```

#### 1.4 配置HTTPS
```
证书类型：免费SSL证书
强制HTTPS：开启
HTTP2：开启
```

### 步骤2：Cloudflare配置（全球免费）

#### 2.1 注册Cloudflare账号
1. 访问 [Cloudflare](https://www.cloudflare.com/)
2. 注册账号并添加域名

#### 2.2 DNS配置
```
A记录：love-timer.yourdomain.com → 119.91.20.202
```

#### 2.3 缓存规则配置
```
缓存级别：标准
页面规则：/api/* -> 绕过缓存
```

## 🖼️ 图片优化配置

### WebP自动转换
```javascript
// 在CDN配置中启用图片处理
转换规则：
- 原始格式：jpg, png
- 转换为：webp（节省30-70%流量）
- 保留原图：作为后备方案
```

### 图片压缩
```javascript
质量设置：
- JPG：质量85%
- PNG：无损压缩
- WebP：质量80%
```

## ⚡ 性能优化代码

### 1. DNS预解析和预连接
```html
<!-- 已在index-cdn.html中配置 -->
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//picsum.photos">
<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
```

### 2. 资源预加载
```html
<!-- 图片预加载 -->
<link rel="preload" as="image" href="背景图片URL">
<!-- 字体预加载 -->
<link rel="preload" href="字体URL" as="style" onload="this.onload=null;this.rel='stylesheet'">
```

### 3. 懒加载实现
```javascript
// 已在index-cdn.html中实现
function lazyLoadImage(element, src) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = new Image();
                img.onload = () => {
                    element.style.backgroundImage = `url(${src})`;
                    observer.disconnect();
                };
                img.src = src;
            }
        });
    });
    observer.observe(element);
}
```

## 📊 监控和分析

### CDN性能监控
1. **腾讯云CDN监控**
   - 流量监控
   - 命中率
   - 响应时间

2. **Cloudflare Analytics**
   - 网站性能
   - 安全威胁
   - 访问统计

### 关键指标
- **缓存命中率**：>90%
- **响应时间**：<500ms
- **可用性**：>99.9%

## 🔄 部署和测试

### 1. 替换原始文件
```bash
# 将优化后的文件上传到服务器
scp index-cdn.html root@119.91.20.202:/root/镜像站_20251124134349/index.html
```

### 2. 配置域名解析
```bash
# DNS配置示例
love-timer.yourdomain.com → CNAME → CDN服务商提供的域名
```

### 3. 测试CDN效果
```bash
# 测试不同地区的访问速度
curl -w "@curl-format.txt" -o /dev/null -s "https://love-timer.yourdomain.com"

# 测试缓存头
curl -I "https://love-timer.yourdomain.com/index.html"
```

## 🎨 前端优化建议

### 1. 代码分割
```javascript
// 将非关键代码延迟加载
const loadGallery = () => {
    import('./gallery.js').then(module => {
        module.initGallery();
    });
};
```

### 2. Service Worker缓存
```javascript
// 缓存静态资源
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open('love-timer-v1').then(cache => {
            return cache.addAll([
                '/',
                '/index.html',
                '/manifest.json'
            ]);
        })
    );
});
```

## 🔒 安全配置

### 1. CDN安全防护
```javascript
// 防盗链设置
Referer黑白名单：只允许指定域名访问

// 访问频率限制
API接口：100次/分钟
静态资源：1000次/分钟
```

### 2. HTTPS强制跳转
```javascript
// 强制HTTPS协议
if (location.protocol !== 'https:') {
    location.replace(`https:${location.href.substring(location.protocol.length)}`);
}
```

## 📈 成本优化

### 1. 流量预估
```
日均PV：1000次
平均页面大小：2MB
月流量：60GB
```

### 2. 成本控制
- 选择合适的计费方式
- 设置流量告警
- 定期清理无用资源

## 🚨 故障处理

### 1. CDN失效处理
```javascript
// 自动回源机制
function loadResource(url, fallbackUrl) {
    return fetch(url)
        .catch(() => fetch(fallbackUrl));
}
```

### 2. 缓存刷新
```bash
# 手动刷新CDN缓存
curl -X POST "CDN_API刷新接口"
```

## 📞 技术支持

### 常见问题
1. **CDN配置生效时间**：通常5-10分钟
2. **HTTPS证书部署**：支持自动续期
3. **跨域问题**：配置CORS头部

### 联系方式
- 腾讯云技术支持：95716
- 官方文档：https://cloud.tencent.com/document/product/228

---

## ✅ 部署清单

- [ ] 选择CDN服务商并注册账号
- [ ] 配置CDN域名和源站地址
- [ ] 设置缓存规则和HTTPS
- [ ] 上传优化后的文件到服务器
- [ ] 配置域名解析
- [ ] 测试CDN加速效果
- [ ] 设置监控和告警
- [ ] 配置安全防护规则

配置完成后，您的爱情计时器网站将获得显著的性能提升！🎉